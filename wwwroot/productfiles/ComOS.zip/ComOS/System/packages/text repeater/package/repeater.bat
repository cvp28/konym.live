@echo off
color 0f
title %packname%
echo %packname% %packversion%
echo.
echo Enter text to repeat...
echo.
set /p text=Input: 
echo.
echo %text%
pause >nul
exit