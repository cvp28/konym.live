echo.
echo ComOS System Console
echo Build 1
echo.
echo help - displays this screen
echo terminate - terminates module
echo clear - clears the screen
echo.
exit /b