@echo off
color 0f
:Calc
cls
title Area of a Triangle Calculator
echo Enter Parameters
echo.
set /p base=Base: 
set /p height=Height: 
set /p measurement="Measurement in use (feet, inches, centimeters, etc.): "
set /a result1="%base% * %height%"
set /a result2="%result1%/2"
echo.
echo.
echo The given parameters have been used to calculate the following area:
echo %result2% %measurement% squared
pause >nul
goto Calc