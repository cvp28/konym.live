let FluxDispatcher = null;

function getDispatcher() {
  if (FluxDispatcher) return FluxDispatcher;

  const chunks = window.webpackChunkdiscord_app;
  if (!Array.isArray(chunks)) return null;

  chunks.push([
    [Symbol()],
    {},
    (require) => {
      const moduleIds = require?.m ? Object.keys(require.m) : [];

      for (const id of moduleIds) {
        try {
          const mod = require(id);
          if (!mod || typeof mod !== "object") continue;

          const candidates = [mod, ...Object.values(mod)];
          for (const candidate of candidates) {
            if (
              candidate &&
              typeof candidate === "object" &&
              typeof candidate.dispatch === "function" &&
              typeof candidate.subscribe === "function" &&
              typeof candidate.addInterceptor === "function" &&
              typeof candidate.isDispatching === "function" &&
              candidate._subscriptions &&
              typeof candidate._subscriptions === "object"
            ) {
              FluxDispatcher = candidate;
              return;
            }
          }
        } catch {
          // Skip modules that throw on early evaluation
        }
      }
    }
  ]);

  return FluxDispatcher;
}

window.addEventListener("EXT_RPC_UPDATE", (event) => {
  const dispatcher = getDispatcher();
  if (!dispatcher) {
    console.warn("[Discord RPC Bridge] FluxDispatcher not found yet.");
    return;
  }

  dispatcher.dispatch({
    type: "LOCAL_ACTIVITY_UPDATE",
    activity: event.detail,
    socketId: "CustomExtensionBridge"
  });
});
