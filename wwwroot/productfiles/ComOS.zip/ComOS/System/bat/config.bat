cls
echo Welcome to ComOS
echo.
echo Some initial data needs to be collected to provide a more personalized experience.
echo NOTE: This menu may be expanded to include more prompts in the future
echo.
echo.
set /p name=Name: 
echo %name%>> %r%\System\user.cfg
echo.
echo All finished!
echo.
echo Press any key to return to ComOS...
pause >nul
exit /b
