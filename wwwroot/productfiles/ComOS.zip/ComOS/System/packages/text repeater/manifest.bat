set packname=Text Repeater
set packversion=1.0

set packtype=Independent
set packinterface=repeater.bat