:Splash3
cls
title Welcome
echo Welcome to ComOS                            #####
echo Alpha 2 - 9/9/16                            #
echo                                             #
echo Press [8] for Setup                         #
echo Press [9] to Abort                          #####
echo.
echo Press [0] to Skip
echo.
echo Continuing in 3 seconds...
echo.
choice /c 8910 /n /t 1 /d 1
if errorlevel 4 exit /b
if errorlevel 3 goto Splash2
if errorlevel 2 exit
if errorlevel 1 call %r%\System\setup.bat

:Splash2
cls
echo Welcome to ComOS                            #####
echo Alpha 2 - 9/9/16                            #
echo                                             #
echo Press [8] for Setup                         #
echo Press [9] to Abort                          #####
echo.
echo Press [0] to Skip
echo.
echo Continuing in 2 seconds...
echo.
choice /c 8910 /n /t 1 /d 1
if errorlevel 4 exit /b
if errorlevel 3 goto Splash1
if errorlevel 2 exit
if errorlevel 1 call %r%\System\setup.bat

:Splash1
cls
echo Welcome to ComOS                            #####
echo Alpha 2 - 9/9/16                            #
echo                                             #
echo Press [8] for Setup                         #
echo Press [9] to Abort                          #####
echo.
echo Press [0] to Skip
echo.
echo Continuing in 1 second...
echo.
choice /c 8910 /n /t 1 /d 1
if errorlevel 4 exit /b
if errorlevel 3 exit /b
if errorlevel 2 exit
if errorlevel 1 call %r%\System\setup.bat