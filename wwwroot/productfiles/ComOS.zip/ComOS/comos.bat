@echo off
color 0f
set r=%~dp0

	if exist %r%\System\flag\idle.flg (
		pause >nul
		goto BootInterface
	)
	if not exist %r%\System\flag\idle.flg (
		goto BootInterface
	)

:BootInterface
cls
title Pre-Boot Interface
echo Pre-Boot Interface
echo.
echo E) Help
echo.
echo 1) Boot Normally
echo 2) Console
echo.
echo 3) Exit
echo.
echo.
set /p bootint="> "
	if %bootint% == E (goto BootInterface_Help)
	if %bootint% == e (goto BootInterface_Help)
	if %bootint% == 1 (goto Boot)
	if %bootint% == 2 (goto BootInterface_Console)
	if %bootint% == 3 (exit)
echo.
echo Error: "%bootint%" - Not a valid option
pause >nul
goto BootInterface

	:BootInterface_Help
	cls
	title Help - PBI
	echo The Pre-Boot Interface is a feature that is loaded before the filecheck.
	echo.
	echo This means that, if important files are missing, it will not interrupt the operation of the PBI and thus makes it useable for recovery purposes.
	echo NOTE: The Pre-Boot Console is a very primitive feature and should not be relied on.
	echo.
	echo.
	echo Press any key to return to the PBI...
	pause >nul
	goto BootInterface

	:BootInterface_Console
	set sessionname=prebootconsole
	set starttime=%time%
	set startdate=%date%
	set outputpath=%r%System\console\
	cls
	echo Pre-Boot Console
	echo Build 2
	:con
	echo.
	echo ��[%sessionname%] [%outputpath%]
	set /p console=��
	
		echo.
		call :BootInterface_Console_%console%
		goto con
	
	:BootInterface_Console_help
		echo Pre-Boot Console Build 2
		echo.
		echo The purpose of this console is to provide recovery and debug features in an environment that does not make use of the filesystem
		echo Use "-help" for more information on commands
		echo.
		echo [Information Bar] ������������������������������������������������
		echo The bar just above the input space is called the information bar
		echo.
		echo LEFT Entry - current session name
		echo RIGHT Entry  - current console output path
		echo.
		echo [Commands] �������������������������������������������������������
		echo help - displays this screen
		echo session - gets information about the current session and allows the user to change session variables
		echo dir - lists a specified directory
		echo clear - clears the screen
		echo er - exits and restarts the system
		echo exit - returns to the Pre-Boot Interface
		echo.
		goto :eof
		
	:BootInterface_Console_session
		set arg1=%~1
		set arg2=%~2
		set arg3=%~3
		if not defined arg1 (
			echo Use "session" with parameters
			goto :eof
		)
		
		if "%arg1%" == "-help" (
			echo List of parameters
			echo.
			echo Used to display, change, and, to a file, output session information
			echo.
			echo -get - used with further parameters to fetch session details
			echo 	details - used with the "get" parameter to fetch session details
			echo.
			echo -change - used with further parameters to change session variables
			echo 	name - used with the "change" parameter to change session name
			echo 		[newsessionname] - will change the session name to the one specified
			echo 	output - used with the "change" parameter to change the current console output path
			echo 		root - will change the output path to the root ComOS directory
			echo 		default - will change the output path to the default console output path
			echo 		[newoutputpath] - will change the output path to the one specified [System\bat]
			echo.
			echo -output - used with further parameters to output session details to a file
			echo 	details - used with the "output" parameter to output session details
			echo 		[filename] - will create a file with the specified name and output session details to that file
			goto :eof
		)
		
		if "%arg1%" == "-get" ( 
			if not defined arg2 (
				echo Use "get" with parameters
				goto :eof
			)
			if "%arg2%" == "details" (
				echo session start time: %starttime%
				echo session start date: %startdate%
				echo current time: %time%
				echo session name: %sessionname%
				echo output path: %outputpath%
				goto :eof
			)
			echo Parameter: "%arg2%" does not exist
			goto :eof
		)
		
		if "%arg1%" == "-change" (
			if not defined arg2 (
				echo Use "change" with parameters
				goto :eof
			)
			if "%arg2%" == "name" (
				if not defined arg3 (
					echo Use "name" with parameters
					goto :eof
				)
				set sessionname=%arg3%
				goto :eof
			)
			if "%arg2%" == "output" (
				if not defined arg3 (
					echo Use "output" with parameters
					goto :eof
				)
				if "%arg3%" == "root" (
					set outputpath=%r%
					goto :eof
				)
				if "%arg3%" == "default" (
					set outputpath=%r%System\console\
					goto :eof
				)
				if exist %r%%arg3% (
					set outputpath=%r%%arg3%\
					goto :eof
				)
				echo Output path invalid
				goto :eof
			)
			echo Parameter: "%arg2%" does not exist
			goto :eof
		)
		echo Parameter: "%arg1%" does not exist
		goto :eof
		
	:BootInterface_Console_crash
	set arg=%~1
	if not defined arg (
		echo Use "crash" with parameters
		goto :eof
	)
	
	if "%arg%" == "-help" (
		echo List of parameters
		echo.
		echo Calls a system crash using user-set parameters
		echo.
		echo [userspecifiederrorcode] - will set the errorcode to be displayed on the crash screen
		goto :eof
	)
	set origin=Pre-Boot Console
	call :crash %arg%
	goto :eof
	
	
		
	:BootInterface_Console_dir
	set arg=%~1
	if not defined arg (
		dir /b /o:G %r%
		goto :eof
	)
	
	if "%arg%" == "-help" (
		echo List of parameters
		echo.
		echo Displays a basic directory listing of the specified directory [limited to ComOS root and above]
		echo.
		echo root - displays root directory
		echo.
		echo [userspecified] - displays a user specified directory with usage [dir System\bat]
		goto :eof
	)
	if "%arg%" == "root" (
		dir /b /o:G %r%
		goto :eof
	)
	dir /b /o:G %r%%arg%
	goto :eof
		
	:BootInterface_Console_test
		set arg=%~1
		if defined arg (
			echo %arg%
		)
		pause >nul
		cls
		goto :eof
	
	:BootInterface_Console_er
		call :reboot
		goto :eof
	
	:BootInterface_Console_clear
		set arg=%~1
		if defined arg (
			echo Clear command does not require parameters
			goto :eof
		)
		cls
		goto :eof
	
	:BootInterface_Console_exit
		goto BootInterface




:Boot
cls
title Booting...
echo Root: "%r%"
echo Begin Boot...
echo.
timeout /t 1 /nobreak >nul
echo Boot start time: %time% >>%r%\System\bootlog.txt
echo Boot start date: %date% >>%r%\System\bootlog.txt
echo. >>%r%\System\bootlog.txt
							REM Verson Information Defining starts here
set logver=B5A1
	echo logver set to %logver% >>%r%\System\bootlog.txt
set ver=Build 5 :: Alpha 1
	echo ver set to %ver% >>%r%\System\bootlog.txt
	echo. >>%r%\System\bootlog.txt
							REM Version Information Defining ends here
if exist %r%\System\err\errorbridge.txt (
	echo Found errorbridge.txt, deleting... >> %r%\System\bootlog.txt
	del %r%\System\err\errorbridge.txt
)
echo errorbridge.txt not found or successfully deleted, starting filecheck... >> %r%\System\bootlog.txt
echo. >> %r%\System\bootlog.txt
																							REM File Check starts here
	if not exist %r%\System\bat\config.bat (echo config.bat >> %r%\System\err\errorbridge.txt)
		if exist %r%\System\bat\config.bat (echo Found config.bat >> %r%\System\bootlog.txt)
		
	if not exist %r%\System\user.cfg (call %r%\System\bat\config.bat)
		if exist %r%\System\user.cfg (echo Found user.cfg >> %r%\System\bootlog.txt)
		
	if not exist %r%\System\bat\splash.bat (echo splash.bat >> %r%\System\err\errorbridge.txt)
		if exist %r%\System\bat\splash.bat (echo Found splash.bat >> %r%\System\bootlog.txt)
		
	if not exist %r%\System\setup.bat (echo setup.bat >> %r%\System\err\errorbridge.txt)
		if exist %r%\System\setup.bat (echo Found setup.bat >> %r%\System\bootlog.txt)
		
	if not exist %r%\System\cmdmenusel.exe (echo cmdmenusel.exe >> %r%\System\err\errorbridge.txt)
		if exist %r%\System\cmdmenusel.exe (echo Found cmdmenusel.exe >> %r%\System\bootlog.txt)
		
	if not exist %r%\System\cmdmenusel.cpp (echo cmdmenusel.cpp >> %r%\System\err\errorbridge.txt)
		if exist %r%\System\cmdmenusel.cpp (echo Found cmdmenusel.cpp >> %r%\System\bootlog.txt)
																							REM File Check ends here
					REM User and OS Variable and Flag Setting starts here
(
set /p name=
) <%r%\System\user.cfg
	echo.  >> %r%\System\bootlog.txt
	echo Processed variable data in user.cfg >> %r%\System\bootlog.txt
	
if exist %r%\System\flag\splash.flg (
	set runsplash=True
	echo Runsplash is "true" >> %r%\System\bootlog.txt
)
if not exist %r%\System\flag\splash.flg (
	set runsplash=False
	echo Runsplash is "false" >> %r%\System\bootlog.txt
)
					REM User and OS Variable and Flag Setting ends here

if exist %r%\System\err\errorbridge.txt (
	echo System failure >> %r%\System\bootlog.txt
	echo ------------------------------------------------------------ >> %r%\System\bootlog.txt
	set origin=Boot
	call :crash bt_mf_0x01
)

if %runsplash% == True (
	echo Boot Complete...
	timeout /t 1 /nobreak >nul
	echo Running splash animation... >> %r%\System\bootlog.txt
	call %r%\System\bat\splash.bat
	echo Loading main menu... >> %r%\System\bootlog.txt
	echo ------------------------------------------------------------ >> %r%\System\bootlog.txt
	goto Main
)
if %runsplash% == False (
	echo Boot Complete...
	timeout /t 1 /nobreak >nul
	echo Loading main menu...  >> %r%\System\bootlog.txt
	echo ------------------------------------------------------------ >> %r%\System\bootlog.txt
	goto Main
)

	:Boot_Error
	cls
	title Error
	echo Error
	echo File(s) needed for safe operation are missing from the ComOS Filesystem...
	echo.
	echo File log -------------------------------------------------------------
	echo.
	type %r%\System\err\errorbridge.txt
	echo.
	echo ----------------------------------------------------------------------
	echo.
	echo Upon exit, ComOS will write the following data and missing file(s) information to the errorbridge.txt and errorlog.txt files in the System\err\ folder
	echo Depending on the status of the user configuration files, name may or may not be defined
	echo.
	echo crash time: %time%
	echo date: %date%
	echo OS version: %logver%
	echo name: %name%
	echo.
	echo The system has been halted...
	pause >nul
	echo crash time: %time%>> %r%\System\err\errorbridge.txt
	echo date: %date%>> %r%\System\err\errorbridge.txt
	echo OS version: %logver%>> %r%\System\err\errorbridge.txt
	echo name: %name%>> %r%\System\err\errorbridge.txt
	echo End of crash report ------------------------------------------------------------>> %r%\System\err\errorbridge.txt
	type %r%\System\err\errorbridge.txt >> %r%\System\err\errorlog.txt
	echo. >> %r%\System\err\errorlog.txt
	exit

:Main
cls
title Main Menu
cd %r%\System
echo ComOS Main
echo %ver%
echo.
echo Welcome back, %name%!
echo.
echo %date%
echo ----------------------------------------------------------------------------------------------
echo.
cmdmenusel f870 "About" "Settings" "Apollo Module Launcher - Under Development" "Reboot" "Exit"

	if %errorlevel% == 1 (
		goto Main_About
	)

	if %errorlevel% == 2 (
		goto Main_Settings
	)
	
	if %errorlevel% == 3 (
		set mod=Normal
		goto Main_Apollo
	)

	if %errorlevel% == 4 (
		call :reboot
	)

	if %errorlevel% == 5 (
		exit
	)
	
	
	:Main_About
	cls
	title About ComOS
	echo About ComOS
	echo %ver%
	echo.
	echo Built On: 10-24-16
	echo.
	echo ComOS was written in Batch by a single developer.
	echo Developer: Carson Ver Planck
	echo.
	echo %ver% Uses:
	echo.
	echo Bootloader: Gen 2 V 1.1
	echo User Interface: Gen 2 V 1.0
	echo.
	echo Description ------------------------------------------------------------------------------
	echo.
	echo ComOS was compiled in "Notepad++" and inspired by "ComputerBooter".
	echo.
	echo For more information on Notepad++, press [N] to go to notepad-plus-plus.org
	echo Else, for more information on ComputerBooter, press [C] to go to notepadcodes.webs.com
	echo.
	echo ------------------------------------------------------------------------------------------
	echo.
	echo Or press [E] to go back to the main menu
	echo.
	choice /c nce /n
	if errorlevel 3 goto Main
	if errorlevel 2 goto Main_About_Redirect2
	if errorlevel 1 goto Main_About_Redirect1
	
		:Main_About_Redirect1
		cls
		start iexplore http://notepad-plus-plus.org
		goto Main_About
		
		:Main_About_Redirect2
		cls
		start iexplore http://notepadcodes.webs.com
		goto Main_About
		
		
	:Main_Settings
	cls
	title Settings
	echo Select an option
	echo.
	cmdmenusel f870 "Change startup settings" "Go back"
	
		if %errorlevel% == 1 (
			goto Main_Settings_Startup
		)

		if %errorlevel% == 2 (
			goto Main
		)
		
		:Main_Settings_Startup
		cls
		if exist %r%\System\flag\idle.flg (
			set idleset=On
		)
		if not exist %r%\System\flag\idle.flg (
			set idleset=Off
		)
		if exist %r%\System\flag\splash.flg (
			set splashset=On
		)
		if not exist %r%\System\flag\splash.flg (
			set splashset=Off
		)
		title Startup Settings
		echo Select an option
		echo.
		echo Startup Idle Status: %idleset%
		echo Splash After Boot Status: %splashset%
		echo.
		cmdmenusel f870 "Change Startup Idle Status" "Change Splash After Boot Status" "Go back"
		
			if %errorlevel% == 1 (
				if %idleset% == On (
					del %r%\System\flag\idle.flg
					goto Main_Settings_Startup
				)
				if %idleset% == Off (
					echo Success> %r%\System\flag\idle.flg
					goto Main_Settings_Startup
				)
			)
			
			if %errorlevel% == 2 (
				if %splashset% == On (
					del %r%\System\flag\splash.flg
					goto Main_Settings_Startup
				)
				if %splashset% == Off (
					echo Success> %r%\System\flag\splash.flg
					goto Main_Settings_Startup
				)
			)
			
			if %errorlevel% == 3 (
				goto Main_Settings
			)
			
			
	:Main_Apollo
	cls
	title Apollo Module Launcher
	cd %r%\System
	echo Apollo Module Launcher
	echo Build 1
	echo ------------------------------------------------------------------------------------------
	echo Mode: %mod%
	echo.
	cmdmenusel f870 "Help" "Change Module System" "KRITS - Under Development" "App Launcher - Under Development" "Version History" "Package Testing" "Go back"
	
	if %errorlevel% == 1 (
		goto Main_Apollo_Help
	)
	
	if %errorlevel% == 2 (
		if "%mod%" == "Normal" (
			set mod=Separate
			goto Main_Apollo
		)
		if "%mod%" == "Separate" (
			set mod=Normal
			goto Main_Apollo
		)
	)
	
	if %errorlevel% == 3 (
		echo KRITS is under development...
		pause >nul
		goto Main_Apollo
	)
	
	if %errorlevel% == 4 (
		echo App Launcher is under development...
		pause >nul
		goto Main_Apollo
	)
		
	if %errorlevel% == 5 (
		goto Main_Apollo_VersionHistory
	)
	
	if %errorlevel% == 6 (
		goto Main_Apollo_PackageTesting
	)
	
	if %errorlevel% == 7 (
		goto Main
	)
	
	:Main_Apollo_Help
	cls
	title Apollo Menu Help
	echo Apollo Menu Help
	echo.
	echo The Apollo Module Launcher is a menu that allows for the launching of "modules" that can run in Normal mode (current OS window) or in Separate mode (new window)
	echo Separate mode allows for a module to be run in a seperate window, snapped using Windows Aero Snap, and resized.
	echo.
	echo This menu is still heavy in development and is suject to numerous changes in future versions.
	echo.
	echo Press any key to go back...
	pause >nul
	goto Main_Apollo
	
	:Main_Apollo_VersionHistory
	cls
	title Version History
	echo Select a version history to view patch notes
	echo.
	echo Patch Files ------------------------------------------------
	dir /b %r%\System\patch
	echo ------------------------------------------------------------
	echo.
	echo Type [exit] to go back
	echo.
	set /p patchselect=Version: 
		if exist %r%\System\patch\%patchselect%.txt (
			cls
			title %patchselect%
			echo.
			type %r%\System\patch\%patchselect%.txt
			pause >nul
			goto Main_Apollo_VersionHistory
		)
		
		if %patchselect% == exit (
			goto Main_Apollo
		)
		
		if not exist %r%\System\patch\%patchselect%.txt (
			echo.
			echo Patch version does not exist
			pause >nul
			goto Main_Apollo_VersionHistory
		)
		
	:Main_Apollo_PackageTesting
	cls
	title Apollo Package Manager
	echo Select a package to load
	echo.
	echo Packages -------------------------------------------------------------
	dir /b /o:G %r%\System\packages\
	echo ----------------------------------------------------------------------
	echo.
	set /p packagename=Package Name: 
		
		if %packagename% == exit (
			goto Main_Apollo
		)
		
		if not exist %r%\System\packages\%packagename% (
			echo Package does not exist
			pause >nul
			goto Main_Apollo_PackageTesting
		)
		
		if not exist %r%\System\packages\%packagename%\manifest.bat (
			echo.
			echo manifest.bat was not found, package can not be loaded
			pause >nul
			goto Main_Apollo_PackageTesting
		)
		
		if exist %r%\System\packages\%packagename%\manifest.bat (
			echo.
			echo Found manifest.bat
			echo.
			call %r%\System\packages\%packagename%\manifest.bat
		)
		
		if not defined packname (
			echo packname is undefined, package name will not be displayed
		)
		
		if not defined packversion (
			echo packversion is undefined, package version will not be displayed
		)
		
		if not defined packtype (
			echo packtype is undefined, will use default to "Reliant"
			set packtype=Reliant
		)
		
		if not defined packinterface (
			echo packinterface is undefined, will use default "interface.bat"
			set packinterface=interface.bat
		)
		
		if %packtype% == Reliant (
			timeout /t 1 /nobreak >nul
			call %r%\System\packages\%packagename%\package\%packinterface%
			pause >nul
			goto Main_Apollo_PackageTesting
		)
		
		if %packtype% == Independent (
			timeout /t 1 /nobreak >nul
			start call %r%\System\packages\%packagename%\package\%packinterface%
			pause >nul
			goto Main_Apollo_PackageTesting
		)






REM OS Functions ----------------------------------------------------------------------------------



:reboot
echo.
echo [1] to skip
cd %r%
echo Current Directory: 
cd
echo.
echo Rebooting in 2 seconds...
choice /c 1 /n /t 2 /d 1
if errorlevel 1 (
	start ComOS.lnk
	exit
)


:crash
echo crash
timeout /t 1 /nobreak >nul
set errorcode=%~1
if not defined origin (set origin=Unknown)
if not defined errorcode (set errorcode=Not specified)
if not defined ver (set ver=Unknown)
cls
title System Failure
echo System Crash iniated from: %origin%
echo Called with errorcode: %errorcode%
echo.
echo Contents of errorbridge.txt ----------------------------------------------
type %r%\System\err\errorbridge.txt
echo --------------------------------------------------------------------------
echo.
																		REM Memory Dump starts here
	echo time: %time%>> %r%\System\err\crash.txt
	echo date: %date%>> %r%\System\err\crash.txt
	echo. >> %r%\System\err\crash.txt
	echo origin: %origin%>> %r%\System\err\crash.txt
	echo errorcode: %errorcode%>> %r%\System\err\crash.txt
	echo. >> %r%\System\err\crash.txt
	echo ver: %logver%>> %r%\System\err\crash.txt
	echo -------------------------------------------------------------------------->> %r%\System\err\crash.txt
																		REM Memory Dump ends here
echo The following data has been written to the filesystem:
echo.
echo time: %time%
echo date: %date%
echo.
echo origin: %origin%
echo errorcode: %errorcode%
echo.
echo ver: %logver%
echo.
echo Press any key to exit...
pause >nul
exit























