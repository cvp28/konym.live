set packtype=Independent
set packinterface="AoT Calculator".bat