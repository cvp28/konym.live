cd %r%\System
:Setup
cls
title Setup Utility
echo ComOS Setup Utility
echo Build 1
echo.
echo Select an option
echo.
cmdmenusel f870 "Change text color" "Reboot"
	if %errorlevel% == 1 goto TextColor
	
	if %errorlevel% == 2 (
		echo.
		echo [1] to skip
		cd %r%
		echo Current Directory: 
		cd
		echo.
		echo Rebooting in 2 seconds...
		choice /c 1 /n /t 2 /d 1
		if errorlevel 1 (
		start ComOS.lnk
		exit)
	)

	:TextColor
	cls
	title Change Text Color Value
	echo Under Development
	pause >nul
	goto Setup