cls
echo %packname% %packversion%
echo.
echo This is a test package
echo All it does is display this text and then move on
echo.
echo.
echo If you're so inclined, here's some behind-the-scenes info about this package
echo.
echo Package Name: %packname%
echo Package Version: %packversion%
echo Package Type: %packtype%
echo Package Interface: %packinterface%
echo.
echo Press any key to close
pause >nul
goto :eof