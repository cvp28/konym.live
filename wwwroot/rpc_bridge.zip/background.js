const NATIVE_HOST_NAME = "com.konymlive.discordrpc";
let nativePort = null;
let activeSourceTabId = null; // Tracks the tab currently owning the RPC status

function broadcastActivity(payload) {
  // 1. Forward to custom .exe (for Discord Desktop)
  try {
    if (!nativePort) {
      nativePort = chrome.runtime.connectNative(NATIVE_HOST_NAME);
      nativePort.onDisconnect.addListener(() => {
        nativePort = null;
      });
    }
    nativePort.postMessage(payload);
  } catch (err) {
    console.warn("Native host not connected:", err);
  }

  // 2. Forward to any open Discord Web tabs
  chrome.tabs.query({ url: "https://discord.com/*" }, (tabs) => {
    for (const tab of tabs) {
      chrome.scripting.executeScript({
        target: { tabId: tab.id },
        world: "MAIN",
        func: (activity) => {
          window.dispatchEvent(new CustomEvent("EXT_RPC_UPDATE", { detail: activity }));
        },
        args: [payload]
      });
    }
  });
}

// Receive updates from your webpage
chrome.runtime.onMessage.addListener((message, sender) => {
  if (message.action === "UPDATE_RPC") {
    activeSourceTabId = message.payload ? sender.tab?.id : null;
    broadcastActivity(message.payload);
  }
});

// Automatically clear RPC if the webpage tab is reloaded or navigated away
chrome.tabs.onUpdated.addListener((tabId, changeInfo) => {
  if (tabId === activeSourceTabId && changeInfo.status === "loading") {
    activeSourceTabId = null;
    broadcastActivity(null);
  }
});

// Automatically clear RPC if the webpage tab is closed
chrome.tabs.onRemoved.addListener((tabId) => {
  if (tabId === activeSourceTabId) {
    activeSourceTabId = null;
    broadcastActivity(null);
  }
});
