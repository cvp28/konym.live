REM This file sets basic variables telling ComOS what this package is and how to handle loading this package

set packname=Test Package
set packversion=0.1

REM packtype can be either "Reliant" or "Independent" -- CASE-SENSITIVE
set packtype=Reliant
set packinterface=gui.bat

goto :eof