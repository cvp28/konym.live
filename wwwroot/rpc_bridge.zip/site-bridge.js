window.addEventListener("message", (event) => {
  // Only accept messages from the same window
  if (event.source !== window) return;

  if (event.data && event.data.type === "SET_DISCORD_RPC") {
    chrome.runtime.sendMessage({
      action: "UPDATE_RPC",
      payload: event.data.payload
    });
  }
});