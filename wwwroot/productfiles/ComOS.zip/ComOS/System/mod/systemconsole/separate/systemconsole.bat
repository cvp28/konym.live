@echo off
color 0f
:Console
cls
title ComOS System Console
cd cmd
echo ComOS System Console
echo Build 1
:con
echo.
set /p con="> "

	if %con% == help (
		call help.bat
		goto con
	)
	
	if %con% == terminate (
		exit /b
	)
	
	if %con% == clear (
		cls
		goto con
	)

echo "%con%" is an unrecognized command.
goto con